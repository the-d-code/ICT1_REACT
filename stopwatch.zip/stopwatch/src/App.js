import './App.css';
import StopWatch from './Components/StopWatch/StopWatch.js';
 
function App() {
    return (
        <div className="App">
            <StopWatch />
        </div>
    );
}
 
export default App;